# 👁️ HORUS - App de Citas para Barberías

App web progresiva (PWA) para reservas de barberías y cuidado personal.

---

## 🚀 CÓMO SUBIR A VERCEL (GRATIS) — PASO A PASO

### PASO 1 — Crea tu cuenta en GitHub (gratis)
1. Ve a **https://github.com**
2. Clic en **"Sign up"**
3. Ingresa tu email, crea contraseña y nombre de usuario
4. Verifica tu email

### PASO 2 — Sube el proyecto a GitHub
1. Estando en GitHub, clic en el botón verde **"New"** (repositorio nuevo)
2. Nombre: `horus-app`
3. Déjalo en **Public**
4. Clic en **"Create repository"**
5. En la página que aparece, clic en **"uploading an existing file"**
6. **Arrastra TODA la carpeta `horus-app`** al área de carga
7. Escribe un mensaje: `Primera versión de HORUS`
8. Clic en **"Commit changes"**

### PASO 3 — Despliega en Vercel (gratis)
1. Ve a **https://vercel.com**
2. Clic en **"Sign up"** → elige **"Continue with GitHub"**
3. Autoriza a Vercel
4. Clic en **"Add New Project"**
5. Busca tu repositorio `horus-app` y clic en **"Import"**
6. En configuración:
   - Framework Preset: **Vite**
   - Build Command: `npm run build`
   - Output Directory: `dist`
7. Clic en **"Deploy"**
8. ¡Espera 2 minutos y listo! 🎉

### RESULTADO
Tu app estará en una URL como:
**https://horus-app.vercel.app**

¡Compártela con tus clientes! Se puede instalar en el celular como app nativa.

---

## 📱 CÓMO INSTALAR EN EL CELULAR (para tus clientes)

### Android (Chrome):
1. Abre la URL en Chrome
2. Aparece un banner "Agregar a pantalla de inicio"
3. O menú (⋮) → "Instalar app"

### iPhone (Safari):
1. Abre la URL en Safari
2. Toca el botón compartir (□↑)
3. Selecciona "Agregar a pantalla de inicio"

---

## 🛠️ Desarrollo local

```bash
npm install
npm run dev
```

Abre http://localhost:5173

---

## 📦 Stack
- React 18
- Vite 5
- PWA (vite-plugin-pwa)
- Claude AI (asistente de chat)
